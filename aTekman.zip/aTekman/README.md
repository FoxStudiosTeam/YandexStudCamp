## DOCS
https://docs.ultralytics.com/tasks/detect/#models